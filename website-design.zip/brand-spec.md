# gemdex — brand spec

Extracted from the repo at `/Users/dks0662779/gemdex` — README badges, brand
art (`assets/logo-wordmark.jpg`, `hero.jpg`, `icon.jpg`), and the desktop app's
own `packages/app/frontend/src/styles.css` (exact token values, not guessed).

## Vibe

Warm, hand-drawn watercolor + cozy retro-handheld. The logo is a sage-green
Game-Boy-style device whose screen shows a glowing gold neural-network brain
with a bookmark node; the wordmark is a chunky terracotta italic script —
"remember once, recall everywhere." Cream paper texture, ink outlines, soft
watercolor blooms. This is a brand where warm paper / cream / terracotta is
**correct and brand-led** (the usual "avoid beige" rule is overridden here).

## Color tokens (real values from app styles.css)

### Light (paper)
| token | hex | oklch |
|---|---|---|
| `--bg` (paper)    | `#f3eadf` | `oklch(94% 0.018 76)` |
| `--surface` (panel)| `#fbf6ee` | `oklch(97% 0.012 80)` |
| `--fg` (ink)      | `#3f3026` | `oklch(30% 0.022 55)` |
| `--muted`         | `#8c7a68` | `oklch(56% 0.022 65)` |
| `--border`        | `#e0d2bf` | `oklch(87% 0.020 78)` |
| `--accent` (rust) | `#c0653a` | `oklch(58% 0.13 42)` |

Support: `--panel-soft #f6eee2`, `--rust-hover #a8512c`, `--sage #8a9a7b`,
`--sage-deep #6f805f`, `--gold #e2a83c`, `--gold-soft #f6e4bd`,
`--faint #a8977f`, `--border-strong #d2bfa6`, `--danger #b5462f`.
Wordmark subtitle slate-blue ≈ `#5f7280`.

### Dark (espresso) — derived to stay warm, not a cold invert
| token | hex |
|---|---|
| `--bg`      | `#1f1813` |
| `--surface` | `#2a221b` |
| `--fg`      | `#f0e6d8` |
| `--muted`   | `#b0a08c` |
| `--border`  | `#3a3026` |
| `--accent`  | `#d67c4f` (rust, lifted for contrast) |
| `--gold`    | `#e9b949` · `--sage` `#9cae8b` |

## Type
- **Display:** Newsreader (warm modern serif; its italic echoes the script wordmark)
- **Body:** Inter (body only)
- **Mono:** JetBrains Mono (code blocks, tool names, paths — heavy use)

## Layout posture
- Soft radii (10–18px), hairline `--border` lines, gentle watercolor-bloom
  background washes (radial gradients in rust/gold/sage at very low alpha).
- One accent (rust) for primary actions; gold reserved for the brain/memory
  motif; sage for "local/safe" signals. No more than ~two accent hits per view.
- Hand-drawn feel via slightly irregular SVG line icons (gold/ink), never emoji.
- Generous whitespace, editorial measure (≤ 68ch), real terminal/code cards.
